<!DOCTYPE html>
<html lang="en">
	<head>
		 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	     <meta name="msapplication-tap-highlight" content="no"> 
	    <meta name="description" content=" ">
	    <title>Gallery - E-Burol Dalisay Funeral Home</title>
	<link href="../css/font-awesome.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="../css/materialize.css">
		<link rel="stylesheet" type="text/css" href="../font-awesome/css/font-awesome.css">
    	<link rel="stylesheet"" type="text/css" href="../css/animate.min.css">
		<link rel="stylesheet" type="text/css" href="../css/style_main.css">
    	<link href="../css/plugins/dropzone/basic.css" rel="stylesheet">
    	<link href="../css/plugins/dropzone/dropzone.css" rel="stylesheet">
    	<link href="../css/responsive.css" rel="stylesheet">
		<script type="text/javascript" src="../js/jquery.js"></script>
		
		<style type="text/css">
				

			
			@media (max-width: 1050px) {
			  ul.dropdown-content {
			    background-color: #ffffff !important;
			  }
			}
			


			#recent-works .col-xs-12.col-sm-4.col-md-3{
			  padding: 0;
			}

			#recent-works{
			    padding-bottom: 70px;
			}

			.recent-work-wrap {
			  position: relative;
			}

			.recent-work-wrap img{
			  width: 100%;
			}

			.recent-work-wrap .recent-work-inner{
			  top: 0;
			  background: transparent;
			  opacity: .8;
			  width: 100%;
			  border-radius: 0;
			  margin-bottom: 0;
			}

			.recent-work-wrap .recent-work-inner h3{
			  margin: 10px 0;
			}

			.recent-work-wrap .recent-work-inner h3 a{
			  font-size: 24px;
			  color: #fff;
			}

			.recent-work-wrap .overlay {
			  position: absolute;
			  top: 0;
			  left: 0;
			  width: 100%;
			  height: 45%;
			  opacity: 0;
			  border-radius: 0;
			  background: #9c27b0;
			  color: #fff;
			  vertical-align: middle;
			   -webkit-transition: opacity 500ms;
			  -moz-transition: opacity 500ms;
			  -o-transition: opacity 500ms;
			  transition: opacity 500ms;  
			  padding: 5px;
			}

			.recent-work-wrap .overlay .preview {
			  bottom: 0;
			  display: inline-block;
			  height: 35px;
			  line-height: 35px;
			  border-radius: 0;
			  background: transparent;
			  text-align: center;
			  color: #fff;
			}

			.recent-work-wrap:hover .overlay {
			  opacity: 0.7;
			}

			.popup {
				position: fixed;
				width: 100%;
				height: 100%;
				top: 0;
				left: 0;
				background: rgba(0, 0 ,0, 0.7);
				z-index: 99;
				text-align: center;
				display: none;
				overflow: auto;
			}

			.disabled{
				border: none;
				background-color: #cdcdcd;
				pointer-events: none;
			}

			.category-heading {
				background:linear-gradient(90deg, transparent, white, rgb(254,78,218));
				color: white;
				padding: 3px 3px 3px 3px;
			}

			@-webkit-keyframes rotating {
				from {
					-webkit-transform: rotate(0deg);

				}

				to {
					-webkit-transform: rotate(360deg);		
				}
			}

			@keyframes rotating {
				from {
					transform: rotate(0deg);

				}

				to {
					transform: rotate(360deg);		
				}
			}

			.circular {
				animation: rotating 1.5s linear infinite;
				position: relative;
			}


			.heading-bar{
				/*border-bottom: 1px solid #0099cc;*/
				box-shadow:  #efefef 1px 1px 1px 2px;
				padding-top: 30px;
				z-index: 2;
				background-color:#fff;	
				top: 0;	
				padding-right: 2%;	

			}

			.fixed-top{	
				position: fixed;
				width: 100%;
			}
			
		</style>
	</head>
	<body>
	
		<div class="row heading-bar fixed-top center-align">
			
			<div class="col s6 l8 m6" style="margin-top: -25px; margin-bottom: 0px;font-size: 2em;margin-top: -15px; margin-bottom: 10px; font-weight: bold; color: #9c27b0;">
				
				<a href="../" class="purple-text"> <span class="hide-on-small-only"> <img src="../images/logo.png"></span></a>
			</div>
			
			<div class="col s6 l4 m6" style="margin-top: -20px; margin-bottom: 0px;">
				<div class=" col l8 m8 s6 right-align">
					<?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>						
					<?php else: ?>
					<a href="../cart">
						<div class="purple-text" style="font-size: 3.5em; cursor: pointer;"><i class="fa fa-shopping-cart"></i></div>
						<div id="cart-count" style="border-radius: 50%; background-color: white; border: 1px solid #9c27b0; color: #9c27b0; position: relative; margin-right: -15px; float: right;  z-index: 99; margin-top:-70px; height: 30px; width: 30px; padding-top: 4px; text-align: center;"><?php if ($cartCount>0) {echo $cartCount;} else {echo 0;}?> </div>
						
					</a>
						
					<?php endif ?>
				</div>

				<div class=" col l4 m4 s6 right-align" style="padding-top: 10px;">
					<?php if (isset($_SESSION['idno'])): ?>
						<a class="dropdown-button" href='#' data-activates='profile-dropdown'>
							<img class="circle" src="<?php if($_SESSION['ppic'] != ''){ echo "../images/profile/".$_SESSION['ppic'];}else{echo "../images/profile/avatar.png";} ?>" height="60px" width="60px">					
						</a>
						<ul id='profile-dropdown' class='dropdown-content' style="margin-top: 2px; margin-left: -20px;">
							 <li><a href="../<?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {echo "admin";} else {echo "home";} ?>"><i class="fa fa-th"></i> Dashboard</a></li>
							 <li class="divider"></li>
							 <li><a href="../logout">Logout <i class="fa fa-sign-out"></i></a></li>
						</ul>
					<?php else: ?>
						<a href="../login?ret=cart" class="btn-flat waves-effect waves-light purple white-text">Log In <i class="fa fa-sign-in"></i></a>
					<?php endif ?>
				</div>

			</div>
		</div>

		<div class="row " style="margin-bottom: 160px; margin-top: 100px; padding-top: 30px;">
		
		<?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>

			<div class="row container center-align white-text">
				<h5>Add New Images</h5>
				<p>To add a New Images, click the button below.</p>

				<button onclick="show_popup('popup-new-ob')" class="btn white purple-text waves-effect waves-purple"><i class="fa fa-plus-circle"></i> Add New Images</button><br><br>
				<hr>
				<h4 class="white-text">Existing Images</h4>
			</div>	
			
		<?php endif ?>

			<div class="row" style="padding-left: 3%; padding-right: 3%;">

			<?php if ($images): ?>
				<?php foreach ($images as $image): ?>
				<div class="col s6 m3 l3 xl3">
					<?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
					<a style="margin-bottom: -70px;" href="?act=del&id=<?=$image['id']?>" class=" btn-large halfway-fab waves-effect waves-light red tooltipped" data-position="top" data-delay="50" data-tooltip="Delete Image"><i class="fa fa-trash"></i></a>
					<?php endif ?>
			      <img src="../images/gallery/<?=$image['image']?>" width="100%">
			    </div>					
				<?php endforeach ?>
			<?php else: ?>
				<h5 class="center-align white-text">No Images.</h5>
			<?php endif ?>

			</div>


		</div>

		<!-- Modal Structure -->
		<div id="popup-new-ob" class="popup">
	        <div class="row container">
	        	<div class="col m1 l1"></div>
	            <div class="col m10 l10 white" style="padding: 10px 10px 10px 10px; margin-top: 10%; border-radius: 10px;">
	            	<span onclick="close_popup('popup-new-ob')" style="cursor: pointer; font-size: 1.5em;" class="right-align right"><i class="fa fa-times-circle red-text"></i></span>


	            	<h5 class="center-align">Add Images</h5><br>

	            	<div class="row">
					    <div class="col-lg-12">
					     <p>To upload images, just drop the images here. You can upload up to <b>100</b> images at the same time.</p>
						    <div class="ibox float-e-margins ">
						                                                   
						        <div class="ibox-content">
						            <form id="my-awesome-dropzone" class="dropzone" action="upload.php">
			                            <div class="dropzone-previews"></div>
			                            <button type="submit" class="btn btn-primary pull-right">Submit this form!</button>
			                        </form>
						            
						        </div>
						    </div>
					    </div>
					</div>
	            </div>
	        	<div class="col m1 l1"></div>
	            	
	        </div>
	    </div>
   
	<!-- End of modal structure -->	

	<!-- Modal Structure -->
		
	<!-- End of modal structure -->	

<div id="preview"></div>
    <script src="../js/jquery-2.1.1.js"></script>
	<script type="text/javascript" src="../js/materialize.min.js"></script>
	<!-- <script type="text/javascript" src="../js/script.js"></script> -->
	<script src="../js/jquery.prettyPhoto.js"></script>
    <script src="../js/plugins/dropzone/dropzone.js"></script>

	<script type="text/javascript">
		

		$(document).ready(function() {
			$('.modal').modal();

			$('.dropdown-button').dropdown({
			      inDuration: 300,
			      outDuration: 225,
			      constrainWidth: false, // Does not change width of dropdown to that of the activator
			      hover: false, // Activate on hover
			      gutter: 20, // Spacing from edge
			      belowOrigin: true, // Displays dropdown below the button
			      alignment: 'right', // Displays dropdown with edge aligned to the left of button
			      stopPropagation: false // Stops event propagation
			});


              $('.datepicker').pickadate({
                    selectMonths: true, // Creates a dropdown to control month
                    selectYears: 35, // Creates a dropdown of 100 years to control year,
                    today: 'Today',
                    max : new Date(),
                    clear: 'Clear',
                    format: 'yyyy-mm-dd',
                    close: 'Ok',
                    cancel: 'Cancel',
                    closeOnSelect: false // Close upon selecting a date,
                });

             Dropzone.options.myAwesomeDropzone = {

                autoProcessQueue: false,
                uploadMultiple: true,
                parallelUploads: 100,
                maxFiles: 100,

                // Dropzone settings
                init: function() {
                    var myDropzone = this;

                    this.element.querySelector("button[type=submit]").addEventListener("click", function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        myDropzone.processQueue();
                    });
                    this.on("sendingmultiple", function() {
                    });
                    this.on("successmultiple", function(files, response) {
                    	$('#preview').html(response);
                    });
                    this.on("errormultiple", function(files, response) {
                    });
                }

            }
			
			//Front View Image manenoss
			$("#front-view-image-div").click(function() {
				$("#front-view-image-file").trigger("click");
			});

			$("#front-view-image-file").change(function(){
	            $("#front-view-image-form-btn").removeClass("hide");
	            $("#image1").removeClass("hide");
	            $("#image1add").addClass("hide");

				var output = document.getElementById('image1img');
				var f_v_url = URL.createObjectURL(event.target.files[0]);
				output.src = f_v_url;
				images[0] = f_v_url;
			 		        
			});
					
		});

		// show_popup : show the popup
		function show_popup(id) {
		
			$('#'+id).show();
		}

		// close_popup : close the popup
		function close_popup(id) {
			// hide the popup
			$('#'+id).hide();
		}

		function uploadImage(form) {
		$('#'+form+'-form-btn').addClass("hide");

	    $('#'+form).ajaxForm({

	        target: '#preview',
	        beforeSend:function(){
	            $('#'+form+'-prog').show();
	            $('#'+form+'-prog').attr('value','0');
	        },
	        uploadProgress:function(event,position,total,percentComplete){
	            $('#'+form+'-prog').attr('value',percentComplete);
	                     
	        }
	                     
	    }).submit();
	}
  

	</script>
	</body>
</html>